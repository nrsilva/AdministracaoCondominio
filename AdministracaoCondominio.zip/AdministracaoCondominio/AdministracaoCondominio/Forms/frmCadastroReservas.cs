﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AdministracaoCondominio.Code.BLL;
using AdministracaoCondominio.Code.DTO;

namespace AdministracaoCondominio
{
    public partial class frmCadastroReservas : Form
    {
        //Inicializando formulario
        public frmCadastroReservas()
        {
            InitializeComponent();
            CarregarGrid();
        }

        // Criação do metodo: "CARREGAR GRID" que preenche o GRID com os dados que já estão cadastrados no banco de dados
        private void CarregarGrid()
        {
            gridReservas.DataSource = bll.SelecionaTodasReservas();
        }

        // Chamando o metodo: "CARREGAR GRID" na inicialização do formulario
        public void frmCadastroReservas_Load(object sender, EventArgs e)
        {
            CarregarGrid();
        }

        // Utilizando o metodo DataGridView para popular o grid com os dados do BAnco de dados
        private void gridReservas_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            txtCodReserva.Text = gridReservas.Rows[e.RowIndex].Cells[0].Value.ToString();
            txtCodCondomino.Text = gridReservas.Rows[e.RowIndex].Cells[1].Value.ToString();
            txtNumUnidade.Text = gridReservas.Rows[e.RowIndex].Cells[2].Value.ToString();
            txtAreaComum.Text = gridReservas.Rows[e.RowIndex].Cells[3].Value.ToString();
            txtDataReserva.Text = gridReservas.Rows[e.RowIndex].Cells[4].Value.ToString();
        }


        //Criação do metodo: "LIMPAR TELA" utililizado para limpar os textbox apos as operações de INSERT, DELETE E UPDATE
        private void LimparTela()
        {
            txtCodReserva.Clear();
            txtCodCondomino.Clear();
            txtNumUnidade.Clear();
            txtAreaComum.Clear();
            txtDataReserva.Clear();
        }

        //criando os construtores bll e dto para fazer referencia aos arquivos de BLL.cs e DTO.cs
        ReservasBLL bll = new ReservasBLL();
        ReservasDTO dto = new ReservasDTO();


        //INICIO BOTÃO GRAVAR
        private void btnGravar_Click(object sender, EventArgs e)
        {
            //criando a comunicação entre os campos do formulario com os atributos do arquivo DTO.cs
            dto.Cod_condomino = int.Parse(txtCodCondomino.Text);
            dto.Num_unidade = int.Parse(txtNumUnidade.Text);
            dto.Area_comum = txtAreaComum.Text;
            dto.Data_reserva = txtDataReserva.Text;
            //Caso o ID esteja vasio, o botão "GRAVAR" utiliza o metodo "INSERIR" do arquivo BLL.cs para inserir os dados prenchidos 
            if (txtCodReserva.Text == "")
            {
                // chamando o metodo "INSERIR" do BLL.cs passando como parametro o dto que são os campos prenchidos
                bll.Inserir(dto);
                // Após a INSERÇÃO é mostrada mensagem de confirmação para o úsuario
                MessageBox.Show("O Item foi incluido com Sucesso!", "Inserido Com Sucesso!", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            //Caso o ID esteja preenchido, o botão "GRAVAR" utiliza o metodo "ATUALIZAR" do arquivo BLL.cs para atualizar os dados prenchidos
            else
            {
                // Para passar o ID é necessario converte-lo em txt usando o comando Parse
                dto.Num_unidade = int.Parse(txtCodReserva.Text);
                // chamando o metodo "ATUALIZAR" do BLL.cs passando como parametro o dto que são os campos prenchidos
                bll.Atualizar(dto);
                // Após a ATUALIZAÇÃO é mostrada mensagem de confirmação para o úsuario
                MessageBox.Show("O Item foi Atualizado com Sucesso!", "Atualizado Com Sucesso!", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            //chamar o metodo "LIMPAR TELA" após finalizar a Inserção ou a atualização
            LimparTela();
            //chamar o metodo "CARREGAR GRID" após finalizar a Inserção ou a atualização
            CarregarGrid();
        }


        // chamando o metodo: "LIMPAR TELA" ao clicar no botão novo
        private void btnNovo_Click(object sender, EventArgs e)
        {
            LimparTela();
        }


        // INICIO BOTÃO EXCLUIR
        private void btnExcluir_Click(object sender, EventArgs e)
        {
           // Só ira excluir se o ID for diferente de vazio, ou seja já esteja cadastrado
            if (txtCodReserva.Text != "")
            {
                // O Úsuario será questionado se deseja prosseguir com a exclusão
                var result = MessageBox.Show("Deseja realmente excluir o registro selecionado?", "Exclusão Fornecedor", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                // Caso a Resposta seja possitiva ira seguir com a exclusão
                if (result == System.Windows.Forms.DialogResult.Yes)
                {
                   // chamar o metodo: "EXCLUIR" do arquivo BLL.cs pasando como parametro o codigo do ID
                    bll.Excluir(txtCodReserva.Text);
                    // Após a EXCLUSÃO é mostrada mensagem de confirmação para o úsuario
                    MessageBox.Show("O Item foi Excluido com Sucesso!", "Atualizado Com Sucesso!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    // chamando o metodo limpar tela
                    LimparTela();
                    // chamando o metodo carregar grid
                    CarregarGrid();

                }
            }
        }

        // Botão fornecedores usado para chamar o form de cadastro de fornecedores
        private void button6_Click(object sender, EventArgs e)
        {
            frmCadastroFornecedor newFormFornecedor = new frmCadastroFornecedor();
            newFormFornecedor.Show();
            this.Visible = false;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            frmCadastroCondominos newFormCondominos = new frmCadastroCondominos();
            newFormCondominos.Show();
            this.Visible = false;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            frmCadastroFuncionario newFormFuncionario = new frmCadastroFuncionario();
            newFormFuncionario.Show();
            this.Visible = false;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            frmCadastroAreaComum newFormAreaComum = new frmCadastroAreaComum();
            newFormAreaComum.Show();
            this.Visible = false;
        }

        private void btnUnidades_Click(object sender, EventArgs e)
        {
            frmCadastroUnidades newFormUnidades = new frmCadastroUnidades();
            newFormUnidades.Show();
            this.Visible = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            frmCadastroReuniao newFormReuniao = new frmCadastroReuniao();
            newFormReuniao.Show();
            this.Visible = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            frmCadastroOcorrencia newFormOcorrencia = new frmCadastroOcorrencia();
            newFormOcorrencia.Show();
            this.Visible = false;
        }
        
    }
}
