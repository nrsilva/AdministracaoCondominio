﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdministracaoCondominio.Code.DTO
{
    class AreaComumDTO
    {
        private int cod_area_comum;

        public int Cod_area_comum
        {
            get { return cod_area_comum; }
            set { cod_area_comum = value; }
        }

        private string nome_area_comum;

        public string Nome_area_comum
        {
            get { return nome_area_comum; }
            set { nome_area_comum = value; }
        }     

    }
}
