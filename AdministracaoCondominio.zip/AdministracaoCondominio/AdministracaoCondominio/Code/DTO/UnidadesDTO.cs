﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdministracaoCondominio.Code.DTO
{
    class UnidadesDTO
    {
        private int num_unidade;

        public int Num_unidade
        {
            get { return num_unidade; }
            set { num_unidade = value; }
        }

        private string tip_unidade;

        public string Tip_unidade
        {
            get { return tip_unidade; }
            set { tip_unidade = value; }
        }

        private int num_andar;

        public int Num_andar
        {
            get { return num_andar; }
            set { num_andar = value; }
        }

        private int num_bloco;

        public int Num_bloco
        {
            get { return num_bloco; }
            set { num_bloco = value; }
        }

    }
}
