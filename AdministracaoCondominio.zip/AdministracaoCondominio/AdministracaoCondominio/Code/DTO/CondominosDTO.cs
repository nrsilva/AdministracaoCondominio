﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdministracaoCondominio.Code.DTO
{
    class CondominosDTO
    {
        private int cd_condomino;

        public int Cd_condomino
        {
            get { return cd_condomino; }
            set { cd_condomino = value; }
        }

        private int cd_condominio;

        public int Cd_condominio
        {
            get { return cd_condominio; }
            set { cd_condominio = value; }
        }

        private string nome_condomino;

        public string Nome_condomino
        {
            get { return nome_condomino; }
            set { nome_condomino = value; }
        }

        private string tipo_condomino;

        public string Tipo_condomino
        {
            get { return tipo_condomino; }
            set { tipo_condomino = value; }
        }

    }
}
