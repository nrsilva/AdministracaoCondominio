﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdministracaoCondominio.Code.DTO
{
    class OcorrenciaDTO
    {
        private int cod_ocorrencia;

        public int Cod_ocorrencia
        {
            get { return cod_ocorrencia; }
            set { cod_ocorrencia = value; }
        }

        private int cod_condomino;

        public int Cod_condomino
        {
            get { return cod_condomino; }
            set { cod_condomino = value; }
        }

        private int cod_funcionario;

        public int Cod_funcionario
        {
            get { return cod_funcionario; }
            set { cod_funcionario = value; }
        }

        private int num_unidade;

        public int Num_unidade
        {
            get { return num_unidade; }
            set { num_unidade = value; }
        }

        private string assunto_ocorrencia;

        public string Assunto_ocorrencia
        {
            get { return assunto_ocorrencia; }
            set { assunto_ocorrencia = value; }
        }

        private string data_ocorrencia;

        public string Data_ocorrencia
        {
            get { return data_ocorrencia; }
            set { data_ocorrencia = value; }
        }

        private string hora_ocorrencia;

        public string Hora_ocorrencia
        {
            get { return hora_ocorrencia; }
            set { hora_ocorrencia = value; }
        }

       

    }
}
