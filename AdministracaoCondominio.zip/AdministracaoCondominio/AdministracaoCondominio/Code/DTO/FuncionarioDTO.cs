﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdministracaoCondominio.Code.DTO
{
    class FuncionarioDTO
    {
        private int cod_funcionario;

        public int Cod_funcionario
        {
            get { return cod_funcionario; }
            set { cod_funcionario = value; }
        }

        private int cod_condominio;

        public int Cod_condominio
        {
            get { return cod_condominio; }
            set { cod_condominio = value; }
        }

        private string nome_funcionario;

        public string Nome_funcionario
        {
            get { return nome_funcionario; }
            set { nome_funcionario = value; }
        }


        private string data_nascimento;

        public string Data_nascimento
        {
            get { return data_nascimento; }
            set { data_nascimento = value; }
        }


        private string rg;

        public string Rg
        {
            get { return rg; }
            set { rg = value; }
        }

        private string cpf;

        public string Cpf
        {
            get { return cpf; }
            set { cpf = value; }
        }

        private string sexo;

        public string Sexo
        {
            get { return sexo; }
            set { sexo = value; }
        }

        private string endereco;

        public string Endereco
        {
            get { return endereco; }
            set { endereco = value; }
        }

        private int num_endereco;

        public int Num_endereco
        {
            get { return num_endereco; }
            set { num_endereco = value; }
        }

        private string bairro;

        public string Bairro
        {
            get { return bairro; }
            set { bairro = value; }
        }

        private string cep;

        public string Cep
        {
            get { return cep; }
            set { cep = value; }
        }

        private string cidade;

        public string Cidade
        {
            get { return cidade; }
            set { cidade = value; }
        }

        private string estado;

        public string Estado
        {
            get { return estado; }
            set { estado = value; }
        }

        private string sigla_estado;

        public string Sigla_estado
        {
            get { return sigla_estado; }
            set { sigla_estado = value; }
        }

        private string telefone;

        public string Telefone
        {
            get { return telefone; }
            set { telefone = value; }
        }

        private string data_contratacao;

        public string Data_contratacao
        {
            get { return data_contratacao; }
            set { data_contratacao = value; }
        }

        private string data_desligamento;

        public string Data_desligamento
        {
            get { return data_desligamento; }
            set { data_desligamento = value; }
        }

        private string cargo;

        public string Cargo
        {
            get { return cargo; }
            set { cargo = value; }
        }

        private string salario;

        public string Salario
        {
            get { return salario; }
            set { salario = value; }
        }
    }     
}
