﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdministracaoCondominio.Code.DTO
{
    class UnidadeDTO
    {
        private int numUnidade;

        public int NumUnidade
        {
            get { return numUnidade; }
            set { numUnidade = value; }
        }

        private string tipUnidade;

        public string TipUnidade
        {
           get { return tipUnidade; }
           set { tipUnidade = value; }
        }
      
        private int numAndar;

        public int NumAndar
        {
            get { return numAndar; }
            set { numAndar = value; }
        } 

        private int numBloco;

        public int NumBloco
        {
            get { return numBloco; }
            set { numBloco = value; }
        }
       
        }
    }
}
