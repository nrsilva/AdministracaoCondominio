﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdministracaoCondominio.Code.DTO
{
    class ReuniaoDTO
    {
        private int cod_reuniao;

        public int Cod_reuniao
        {
            get { return cod_reuniao; }
            set { cod_reuniao = value; }
        }

        private int cod_condomino;

        public int Cod_condomino
        {
            get { return cod_condomino; }
            set { cod_condomino = value; }
        }

        private string tipo_reuniao;

        public string Tipo_reuniao
        {
            get { return tipo_reuniao; }
            set { tipo_reuniao = value; }
        }

        private string assunto_reuniao;

        public string Assunto_reuniao
        {
            get { return assunto_reuniao; }
            set { assunto_reuniao = value; }
        }

        private string data_reuniao;

        public string Data_reuniao
        {
            get { return data_reuniao; }
            set { data_reuniao = value; }
        }

    }
}
