﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdministracaoCondominio.Code.DTO
{
    class ReservasDTO
    {
        private int cod_reserva;

        public int Cod_reserva
        {
            get { return cod_reserva; }
            set { cod_reserva = value; }
        }

        private int cod_condomino;

        public int Cod_condomino
        {
            get { return cod_condomino; }
            set { cod_condomino = value; }
        }

        private int num_unidade;

        public int Num_unidade
        {
            get { return num_unidade; }
            set { num_unidade = value; }
        }

        private string area_comum;

        public string Area_comum
        {
            get { return area_comum; }
            set { area_comum = value; }
        }

        private string data_reserva;

        public string Data_reserva
        {
            get { return data_reserva; }
            set { data_reserva = value; }
        }

    }
}
