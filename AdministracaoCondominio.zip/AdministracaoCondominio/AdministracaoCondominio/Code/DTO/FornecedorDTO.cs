﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdministracaoCondominio.Code.DTO
{
    class FornecedorDTO
    {
        private int cod_fornecedor;

        public int Cod_fornecedor
        {
            get { return cod_fornecedor; }
            set { cod_fornecedor = value; }
        }

        private int cod_condominio;

        public int Cod_condominio
        {
            get { return cod_condominio; }
            set { cod_condominio = value; }
        }

        private string nome_fornecedor;

        public string Nome_fornecedor
        {
            get { return nome_fornecedor; }
            set { nome_fornecedor = value; }
        }

        private string cnpj;

        public string Cnpj
        {
            get { return cnpj; }
            set { cnpj = value; }
        }

        private string rg;

        public string Rg
        {
            get { return rg; }
            set { rg = value; }
        }

        private string cpf;

        public string Cpf
        {
            get { return cpf; }
            set { cpf = value; }
        }

        private string endereco;

        public string Endereco
        {
            get { return endereco; }
            set { endereco = value; }
        }

        private int num_endereco;

        public int Num_endereco
        {
            get { return num_endereco; }
            set { num_endereco = value; }
        }

        private string bairro;

        public string Bairro
        {
            get { return bairro; }
            set { bairro = value; }
        }

        private string cep;

        public string Cep
        {
            get { return cep; }
            set { cep = value; }
        }

        private string cidade;

        public string Cidade
        {
            get { return cidade; }
            set { cidade = value; }
        }

        private string estado;

        public string Estado
        {
            get { return estado; }
            set { estado = value; }
        }

        private string sigla_estado;

        public string Sigla_estado
        {
            get { return sigla_estado; }
            set { sigla_estado = value; }
        }

        private string telefone;

        public string Telefone
        {
            get { return telefone; }
            set { telefone = value; }
        }

        private string observacao;

        public string Observacao
        {
            get { return observacao; }
            set { observacao = value; }
        }

    }     
}
