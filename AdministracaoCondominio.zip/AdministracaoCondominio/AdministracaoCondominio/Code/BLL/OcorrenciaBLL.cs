﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using AdministracaoCondominio.Code.DTO;
using DAL;

namespace AdministracaoCondominio.Code.BLL
{
    class OcorrenciaBLL
    {
        AcessoBancoDados bd;

        public void Inserir(OcorrenciaDTO dto)
        {
            try
            {

                bd = new AcessoBancoDados();
                bd.Conectar();
                string comando = "INSERT INTO ocorrencia(cod_condomino, cod_funcionario, num_unidade, assunto_ocorrencia, data_ocorrencia, hora_ocorrencia) VALUES ('" + dto.Cod_condomino + "','" + dto.Cod_funcionario + "','" + dto.Num_unidade + "','" + dto.Assunto_ocorrencia + "','" + dto.Data_ocorrencia + "','" + dto.Hora_ocorrencia + "')";
                bd.ExecutarComandoSQL(comando);
            }

            catch (Exception ex)
            {
                throw new Exception("Erro ao tentar cadastrar Item: " + ex.Message);
            }

            finally
            {
                bd = null;
            }


        }

        public DataTable SelecionaTodasOcorrencias()
        {
            DataTable dt = new DataTable();
            
            try 
            {
                bd = new AcessoBancoDados();
                bd.Conectar();

                dt = bd.RetDataTable("SELECT cod_ocorrencia, cod_condomino, cod_funcionario, num_unidade, assunto_ocorrencia, data_ocorrencia, hora_ocorrencia from ocorrencia");
            }

            catch (Exception ex)
            {
                throw new Exception("Erro ao tentar selecionar todos Itens: " + ex.Message);
            }

            finally
            {
                bd = null;
            }

            return dt;

        }

        public void Atualizar(OcorrenciaDTO dto)
        {
            try
            {

                bd = new AcessoBancoDados();    
                bd.Conectar();
                string comando = "UPDATE ocorrencia set cod_condomino = '" + dto.Cod_condomino + "', cod_funcionario = '" + dto.Cod_funcionario + "' , num_unidade = '" + dto.Num_unidade + "' , assunto_ocorrencia = '" + dto.Assunto_ocorrencia + "', data_ocorrencia = '" + dto.Data_ocorrencia + "' , hora_ocorrencia = '" + dto.Hora_ocorrencia + "' where cod_ocorrencia =" + dto.Cod_ocorrencia;
                bd.ExecutarComandoSQL(comando);
            }

            catch (Exception ex)
            {
                throw new Exception("Erro ao tentar atualizar Item: " + ex.Message);
            }

            finally
            {
                bd = null;
            }


        }

        public void Excluir(string IdOcorrencia)
        {
            try
            {
                bd = new AcessoBancoDados();
                bd.Conectar();
                string comando = "DELETE from ocorrencia where cod_ocorrencia =" + IdOcorrencia;
                bd.ExecutarComandoSQL(comando);
            }

            catch (Exception ex)
            {
                throw new Exception("Erro ao tentar excluir Item: " + ex.Message);
            }

            finally
            {
                bd = null;
            }


        }

    }
}
