﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using AdministracaoCondominio.Code.DTO;
using DAL;

namespace AdministracaoCondominio.Code.BLL
{
    class FornecedorBLL
    {
        AcessoBancoDados bd;

        public void Inserir(FornecedorDTO dto)
        {
            try
            {
                bd = new AcessoBancoDados();
                bd.Conectar();
                string comando = "INSERT INTO fornecedores (cod_condominio,nome_fornecedor,CNPJ,RG,CPF,endereco,num_endereco,bairro,CEP,cidade,estado,sigla_estado,telefone,observacao) VALUES ('" + dto.Cod_condominio + "','" + dto.Nome_fornecedor + "','" + dto.Cnpj + "','" + dto.Rg + "','" + dto.Cpf + "','" + dto.Endereco + "','" + dto.Num_endereco + "','" + dto.Bairro + "','" + dto.Cep + "','" + dto.Cidade+ "','" + dto.Estado + "','" + dto.Sigla_estado + "','" + dto.Telefone + "','" + dto.Observacao + "')";
                bd.ExecutarComandoSQL(comando);
            }

            catch (Exception ex)
            {
                throw new Exception("Erro ao tentar cadastrar Fornecedor: " + ex.Message);
            }

            finally
            {
                bd = null;
            }


        }

        public DataTable SelecionaTodosFornecedores()
        {
            DataTable dt = new DataTable();
            
            try 
            {
                bd = new AcessoBancoDados();
                bd.Conectar();

                dt = bd.RetDataTable("SELECT cod_fornecedor,cod_condominio,nome_fornecedor,CNPJ,RG,CPF,endereco,num_endereco,bairro,CEP,cidade,estado,sigla_estado,telefone,observacao  from fornecedores");
            }

            catch (Exception ex)
            {
                throw new Exception("Erro ao tentar selecionar todos Fornecedores: " + ex.Message);
            }

            finally
            {
                bd = null;
            }

            return dt;

        }

        public void Atualizar(FornecedorDTO dto)
        {
            try
            {
                bd = new AcessoBancoDados();    
                bd.Conectar();
                string comando = "UPDATE fornecedores set cod_condominio= '" + dto.Cod_condominio + "',nome_fornecedor= '" + dto.Nome_fornecedor + "',CNPJ= '" + dto.Cnpj + "',RG= '" + dto.Rg+ "',CPF= '" + dto.Cpf + "',endereco= '" + dto.Endereco + "',num_endereco= '" + dto.Num_endereco + "',bairro= '" + dto.Bairro + "',CEP= '" + dto.Cep + "',cidade= '" + dto.Cidade + "',estado= '" + dto.Estado + "',sigla_estado= '" + dto.Sigla_estado + "',telefone= '" + dto.Telefone + "',observacao= '" + dto.Observacao + "'  where cod_fornecedor =" + dto.Cod_fornecedor;
                bd.ExecutarComandoSQL(comando);
            }

            catch (Exception ex)
            {
                throw new Exception("Erro ao tentar atualizar Fornecedor: " + ex.Message);
            }

            finally
            {
                bd = null;
            }


        }

        public void Excluir(string CodFornecedores)
        {
            try
            {
                bd = new AcessoBancoDados();
                bd.Conectar();
                string comando = "DELETE from fornecedores where cod_fornecedor =" + CodFornecedores;
                bd.ExecutarComandoSQL(comando);
            }

            catch (Exception ex)
            {
                throw new Exception("Erro ao tentar excluir Fornecedor: " + ex.Message);
            }

            finally
            {
                bd = null;
            }


        }

    }
}
