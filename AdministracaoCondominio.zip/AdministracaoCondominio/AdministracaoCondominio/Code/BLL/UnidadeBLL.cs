﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using AdministracaoCondominio.Code.DTO;
using DAL;

namespace AdministracaoCondominio.Code.BLL
{
    class UnidadeBLL
    {
        AcessoBancoDados bd;

        public void Inserir(UnidadeDTO dto)
        {
            try
            {
                bd = new AcessoBancoDados();
                bd.Conectar();
                string comando = "INSERT INTO unidade (tip_unidade, num_andar, num_bloco) VALUES ('" + dto.TipUnidade + "','" + dto.NumAndar + "','"+ dto.NumBloco +"')";
                bd.ExecutarComandoSQL(comando);
            }

            catch (Exception ex)
            {
                throw new Exception("Erro ao tentar inserir registro: " + ex.Message);
            }

            finally
            {
                bd = null;
            }


        }

        public DataTable SelecionaTodos()
        {
            DataTable dt = new DataTable();
            
            try 
            {
                bd = new AcessoBancoDados();
                bd.Conectar();

                dt = bd.RetDataTable ("SELECT num_unidade, tip_unidade, num_andar, num_bloco from unidade");
            }

            catch (Exception ex)
            {
                throw new Exception("Erro ao tentar selecionar Todos: " + ex.Message);
            }

            finally
            {
                bd = null;
            }

            return dt;

        }

        public void Atualizar(UnidadeDTO dto)
        {
            try
            {
                bd = new AcessoBancoDados();    
                bd.Conectar();
                string comando = "UPDATE unidade set tip_unidade = '" + dto.TipUnidade + "', num_andar = '" + dto.NumAndar + "', num_bloco = '"+ dto.NumBloco +"' where id =" + dto.NumUnidade;
                bd.ExecutarComandoSQL(comando);
            }

            catch (Exception ex)
            {
                throw new Exception("Erro ao tentar atualizar registro: " + ex.Message);
            }

            finally
            {
                bd = null;
            }


        }

        public void Excluir(string IdUnidade)
        {
            try
            {
                bd = new AcessoBancoDados();
                bd.Conectar();
                string comando = "DELETE from unidade where id =" + IdUnidade;
                bd.ExecutarComandoSQL(comando);
            }

            catch (Exception ex)
            {
                throw new Exception("Erro ao tentar excluir Registro: " + ex.Message);
            }

            finally
            {
                bd = null;
            }


        }

    }
}
