﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using AdministracaoCondominio.Code.DTO;
using DAL;

namespace AdministracaoCondominio.Code.BLL
{
    class UnidadesBLL
    {
        AcessoBancoDados bd;

        public void Inserir(UnidadesDTO dto)
        {
            try
            {

                bd = new AcessoBancoDados();
                bd.Conectar();
                string comando = "INSERT INTO unidade(num_unidade,tip_unidade,num_andar,num_bloco) VALUES ('" + dto.Num_unidade + "','" + dto.Tip_unidade + "','" + dto.Num_andar + "','" + dto.Num_bloco + "')";
                bd.ExecutarComandoSQL(comando);
            }

            catch (Exception ex)
            {
                throw new Exception("Erro ao tentar cadastrar Item: " + ex.Message);
            }

            finally
            {
                bd = null;
            }


        }

        public DataTable SelecionaTodasUnidades()
        {
            DataTable dt = new DataTable();
            
            try 
            {
                bd = new AcessoBancoDados();
                bd.Conectar();

                dt = bd.RetDataTable("SELECT num_unidade,tip_unidade,num_andar,num_bloco from unidade");
            }

            catch (Exception ex)
            {
                throw new Exception("Erro ao tentar selecionar todos Itens: " + ex.Message);
            }

            finally
            {
                bd = null;
            }

            return dt;

        }

        public void Atualizar(UnidadesDTO dto)
        {
            try
            {

                bd = new AcessoBancoDados();    
                bd.Conectar();
                string comando = "UPDATE unidade set tip_unidade = '" + dto.Tip_unidade + "', num_andar = '" + dto.Num_andar + "',num_bloco = '" + dto.Num_bloco + "' where id =" + dto.Num_unidade;
                bd.ExecutarComandoSQL(comando);
            }

            catch (Exception ex)
            {
                throw new Exception("Erro ao tentar atualizar Item: " + ex.Message);
            }

            finally
            {
                bd = null;
            }


        }

        public void Excluir(string IdUnidade)
        {
            try
            {
                bd = new AcessoBancoDados();
                bd.Conectar();
                string comando = "DELETE from unidade where num_unidade =" + IdUnidade;
                bd.ExecutarComandoSQL(comando);
            }

            catch (Exception ex)
            {
                throw new Exception("Erro ao tentar excluir Item: " + ex.Message);
            }

            finally
            {
                bd = null;
            }


        }

    }
}
