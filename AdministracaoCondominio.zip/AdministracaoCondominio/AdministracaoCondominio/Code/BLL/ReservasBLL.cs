﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using AdministracaoCondominio.Code.DTO;
using DAL;

namespace AdministracaoCondominio.Code.BLL
{
    class ReservasBLL
    {
        AcessoBancoDados bd;

        public void Inserir(ReservasDTO dto)
        {
            try
            {

                bd = new AcessoBancoDados();
                bd.Conectar();
                string comando = "INSERT INTO reserva(cod_condomino, num_unidade, area_comum, data_reserva) VALUES ('" + dto.Cod_condomino + "','" + dto.Num_unidade + "','" + dto.Area_comum + "','" + dto.Data_reserva + "')";
                bd.ExecutarComandoSQL(comando);
            }

            catch (Exception ex)
            {
                throw new Exception("Erro ao tentar cadastrar Item: " + ex.Message);
            }

            finally
            {
                bd = null;
            }


        }

        public DataTable SelecionaTodasReservas()
        {
            DataTable dt = new DataTable();
            
            try 
            {
                bd = new AcessoBancoDados();
                bd.Conectar();

                dt = bd.RetDataTable("SELECT cod_reserva, cod_condomino, num_unidade, area_comum, data_reserva from reserva");
            }

            catch (Exception ex)
            {
                throw new Exception("Erro ao tentar selecionar todos Itens: " + ex.Message);
            }

            finally
            {
                bd = null;
            }

            return dt;

        }

        public void Atualizar(ReservasDTO dto)
        {
            try
            {

                bd = new AcessoBancoDados();    
                bd.Conectar();
                string comando = "UPDATE reserva set cod_condomino= '" + dto.Cod_condomino + "', num_unidade= '" + dto.Num_unidade + "', area_comum= '" + dto.Area_comum + "', data_reserva= '" + dto.Data_reserva + "' where cod_reserva =" + dto.Cod_reserva;
                bd.ExecutarComandoSQL(comando);
            }

            catch (Exception ex)
            {
                throw new Exception("Erro ao tentar atualizar Item: " + ex.Message);
            }

            finally
            {
                bd = null;
            }


        }

        public void Excluir(string IdReserva)
        {
            try
            {
                bd = new AcessoBancoDados();
                bd.Conectar();
                string comando = "DELETE from reserva where cod_reserva =" + IdReserva;
                bd.ExecutarComandoSQL(comando);
            }

            catch (Exception ex)
            {
                throw new Exception("Erro ao tentar excluir Item: " + ex.Message);
            }

            finally
            {
                bd = null;
            }


        }

    }
}
