﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using AdministracaoCondominio.Code.DTO;
using DAL;

namespace AdministracaoCondominio.Code.BLL
{
    class ReuniaoBLL
    {
        AcessoBancoDados bd;

        public void Inserir(ReuniaoDTO dto)
        {
            try
            {

                bd = new AcessoBancoDados();
                bd.Conectar();
                string comando = "INSERT INTO reuniao( cod_condomino, tipo_reuniao, assunto_reuniao, data_reuniao) VALUES ('" + dto.Cod_condomino + "','" + dto.Tipo_reuniao + "','" + dto.Assunto_reuniao + "','" + dto.Data_reuniao + "')";
                bd.ExecutarComandoSQL(comando);
            }

            catch (Exception ex)
            {
                throw new Exception("Erro ao tentar cadastrar Item: " + ex.Message);
            }

            finally
            {
                bd = null;
            }


        }

        public DataTable SelecionaTodasReunioes()
        {
            DataTable dt = new DataTable();
            
            try 
            {
                bd = new AcessoBancoDados();
                bd.Conectar();

                dt = bd.RetDataTable("SELECT cod_reuniao, cod_condomino, tipo_reuniao, assunto_reuniao, data_reuniao from reuniao");
            }

            catch (Exception ex)
            {
                throw new Exception("Erro ao tentar selecionar todos Itens: " + ex.Message);
            }

            finally
            {
                bd = null;
            }

            return dt;

        }

        public void Atualizar(ReuniaoDTO dto)
        {
            try
            {

                bd = new AcessoBancoDados();    
                bd.Conectar();
                string comando = "UPDATE reuniao set cod_condomino= '" + dto.Cod_condomino + "', tipo_reuniao= '" + dto.Tipo_reuniao + "', assunto_reuniao= '" + dto.Assunto_reuniao+ "', data_reuniao= '" + dto.Data_reuniao + "' where cod_reuniao =" + dto.Cod_reuniao;
                bd.ExecutarComandoSQL(comando);
            }

            catch (Exception ex)
            {
                throw new Exception("Erro ao tentar atualizar Item: " + ex.Message);
            }

            finally
            {
                bd = null;
            }


        }

        public void Excluir(string IdReuniao)
        {
            try
            {
                bd = new AcessoBancoDados();
                bd.Conectar();
                string comando = "DELETE from reuniao where cod_reuniao =" + IdReuniao;
                bd.ExecutarComandoSQL(comando);
            }

            catch (Exception ex)
            {
                throw new Exception("Erro ao tentar excluir Item: " + ex.Message);
            }

            finally
            {
                bd = null;
            }


        }

    }
}
