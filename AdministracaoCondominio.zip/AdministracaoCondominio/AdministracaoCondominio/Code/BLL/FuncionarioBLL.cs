﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using AdministracaoCondominio.Code.DTO;
using DAL;

namespace AdministracaoCondominio.Code.BLL
{
    class FuncionarioBLL
    {
        AcessoBancoDados bd;

        public void Inserir(FuncionarioDTO dto)
        {
            try
            {
                //Tratamento de exceção de Apóstrofe - exemplo: nome Joana D'Arc
                string nome = dto.Nome_funcionario.Replace("'", "''");

                bd = new AcessoBancoDados();
                bd.Conectar();
                string comando = "INSERT INTO funcionario (cod_condominio, nome_funcionario, data_nascimento,RG, CPF, sexo, endereco, num_endereco, bairro, CEP, cidade, estado, sigla_estado, telefone, data_contratacao, data_desligamento, cargo, salario) VALUES ('" + dto.Cod_condominio + "','" + nome + "','" + dto.Data_nascimento + "','" + dto.Rg + "','" + dto.Cpf + "','" + dto.Sexo + "','" + dto.Endereco + "','" + dto.Num_endereco + "','" + dto.Bairro + "','" + dto.Cep + "','" + dto.Cidade + "','" + dto.Estado + "','" + dto.Sigla_estado + "','" + dto.Telefone + "','" + dto.Data_contratacao + "','" + dto.Data_desligamento + "','" + dto.Cargo + "','" + dto.Salario + "')";
                bd.ExecutarComandoSQL(comando);
            }

            catch (Exception ex)
            {
                throw new Exception("Erro ao tentar cadastrar Item: " + ex.Message);
            }

            finally
            {
                bd = null;
            }


        }

        public DataTable SelecionaTodosFuncionarios()
        {
            DataTable dt = new DataTable();
            
            try 
            {
                bd = new AcessoBancoDados();
                bd.Conectar();

                dt = bd.RetDataTable("SELECT cod_funcionario, cod_condominio, nome_funcionario, data_nascimento, RG, CPF, sexo, endereco, num_endereco, bairro, CEP, cidade, estado, sigla_estado, telefone, data_contratacao, data_desligamento, cargo, salario from funcionario");
            }

            catch (Exception ex)
            {
                throw new Exception("Erro ao tentar selecionar todos Itens: " + ex.Message);
            }

            finally
            {
                bd = null;
            }

            return dt;

        }

        public void Atualizar(FuncionarioDTO dto)
        {
            try
            {
                bd = new AcessoBancoDados();    
                bd.Conectar();
                string comando = "UPDATE funcionario set cod_condominio= '" + dto.Cod_condominio + "',nome_funcionario= '" + dto.Nome_funcionario + "',data_nascimento = '" + dto.Data_nascimento + "',RG= '" + dto.Rg + "',CPF= '" + dto.Cpf + "', sexo= '" + dto.Sexo + "' ,endereco= '" + dto.Endereco + "',num_endereco= '" + dto.Num_endereco + "',bairro= '" + dto.Bairro + "',CEP= '" + dto.Cep + "',cidade= '" + dto.Cidade + "',estado= '" + dto.Estado + "',sigla_estado= '" + dto.Sigla_estado + "',telefone= '" + dto.Telefone + "', data_contratacao = '" + dto.Data_contratacao + "', data_desligamento = '" + dto.Data_desligamento + "', cargo = '" + dto.Cargo + "', salario = '" + dto.Salario + "'  where cod_fornecedor =" + dto.Cod_funcionario;
                bd.ExecutarComandoSQL(comando);
            }

            catch (Exception ex)
            {
                throw new Exception("Erro ao tentar atualizar Itens: " + ex.Message);
            }

            finally
            {
                bd = null;
            }


        }

        public void Excluir(string CodFuncionario)
        {
            try
            {
                bd = new AcessoBancoDados();
                bd.Conectar();
                string comando = "DELETE from fornecedores where cod_fornecedor =" + CodFuncionario;
                bd.ExecutarComandoSQL(comando);
            }

            catch (Exception ex)
            {
                throw new Exception("Erro ao tentar excluir Item: " + ex.Message);
            }

            finally
            {
                bd = null;
            }


        }

    }
}
