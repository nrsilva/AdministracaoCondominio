﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using AdministracaoCondominio.Code.DTO;
using DAL;

namespace AdministracaoCondominio.Code.BLL
{
    class AreaComumBLL
    {
        AcessoBancoDados bd;

        public void Inserir(AreaComumDTO dto)
        {
            try
            {

                bd = new AcessoBancoDados();
                bd.Conectar();
                string comando = "INSERT INTO area_comum(nome_area_comum) VALUES ('" + dto.Nome_area_comum + "')";
                bd.ExecutarComandoSQL(comando);
            }

            catch (Exception ex)
            {
                throw new Exception("Erro ao tentar cadastrar Item: " + ex.Message);
            }

            finally
            {
                bd = null;
            }


        }

        public DataTable SelecionaTodasAreasComuns()
        {
            DataTable dt = new DataTable();
            
            try 
            {
                bd = new AcessoBancoDados();
                bd.Conectar();

                dt = bd.RetDataTable("SELECT cod_area_comum, nome_area_comum from area_comum");
            }

            catch (Exception ex)
            {
                throw new Exception("Erro ao tentar selecionar todos Itens: " + ex.Message);
            }

            finally
            {
                bd = null;
            }

            return dt;

        }

        public void Atualizar(AreaComumDTO dto)
        {
            try
            {

                bd = new AcessoBancoDados();    
                bd.Conectar();
                string comando = "UPDATE area_comum set nome_area_comum = '" + dto.Nome_area_comum+ "' where id =" + dto.Cod_area_comum;
                bd.ExecutarComandoSQL(comando);
            }

            catch (Exception ex)
            {
                throw new Exception("Erro ao tentar atualizar Item: " + ex.Message);
            }

            finally
            {
                bd = null;
            }


        }

        public void Excluir(string IdAreaComum)
        {
            try
            {
                bd = new AcessoBancoDados();
                bd.Conectar();
                string comando = "DELETE from area_comum where cod_area_comum =" + IdAreaComum;
                bd.ExecutarComandoSQL(comando);
            }

            catch (Exception ex)
            {
                throw new Exception("Erro ao tentar excluir Item: " + ex.Message);
            }

            finally
            {
                bd = null;
            }


        }

    }
}
