﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using AdministracaoCondominio.Code.DTO;
using DAL;

namespace AdministracaoCondominio.Code.BLL
{
    class CondominosBLL
    {
        AcessoBancoDados bd;

        public void Inserir(CondominosDTO dto)
        {
            try
            {

                bd = new AcessoBancoDados();
                bd.Conectar();
                string comando = "INSERT INTO condominos(cod_condominio, nome_condomino, tipo_condomino) VALUES ('" + dto.Cd_condominio + "','" + dto.Nome_condomino + "','" + dto.Tipo_condomino + "')";
                bd.ExecutarComandoSQL(comando);
            }

            catch (Exception ex)
            {
                throw new Exception("Erro ao tentar cadastrar Item: " + ex.Message);
            }

            finally
            {
                bd = null;
            }


        }

        public DataTable SelecionaTodosCondominos()
        {
            DataTable dt = new DataTable();
            
            try 
            {
                bd = new AcessoBancoDados();
                bd.Conectar();

                dt = bd.RetDataTable("SELECT cod_condomino, cod_condominio, nome_condomino, tipo_condomino from condominos");
            }

            catch (Exception ex)
            {
                throw new Exception("Erro ao tentar selecionar todos Itens: " + ex.Message);
            }

            finally
            {
                bd = null;
            }

            return dt;

        }

        public void Atualizar(CondominosDTO dto)
        {
            try
            {

                bd = new AcessoBancoDados();    
                bd.Conectar();
                string comando = "UPDATE condominos set cod_condominio = '" + dto.Cd_condominio + "', nome_condomino = '" + dto.Nome_condomino + "', tipo_condomino = '" + dto.Tipo_condomino + "' where cod_condomino =" + dto.Cd_condomino;
                bd.ExecutarComandoSQL(comando);
            }

            catch (Exception ex)
            {
                throw new Exception("Erro ao tentar atualizar Item: " + ex.Message);
            }

            finally
            {
                bd = null;
            }


        }

        public void Excluir(string CodCondomino)
        {
            try
            {
                bd = new AcessoBancoDados();
                bd.Conectar();
                string comando = "DELETE from condominos where cod_condomino =" + CodCondomino;
                bd.ExecutarComandoSQL(comando);
            }

            catch (Exception ex)
            {
                throw new Exception("Erro ao tentar excluir item: " + ex.Message);
            }

            finally
            {
                bd = null;
            }


        }

    }
}
